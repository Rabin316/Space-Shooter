# PixelSpace

Code available under MIT license, but do not distribute or sell any generated images on their own.
Feel free to use them in your games or other projects however.
